package ru.geekbrain.java3.dz.dz1.MakosovAleksandr.path3;

public class Orange extends Fruit {
    public Orange(String name, Float weight) {
        super(name, weight);
    }
}
