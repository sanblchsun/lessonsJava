package ru.geekbrains.java3.dz.dz1.VeretennikovSergey;

public abstract class Fruit {
    public abstract float getWeight();
}
