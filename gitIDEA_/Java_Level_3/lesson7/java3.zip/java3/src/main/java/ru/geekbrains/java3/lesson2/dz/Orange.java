package ru.geekbrains.java3.lesson2.dz;

/**
 * Апельсинки
 */
public class Orange extends Fruit {

    Orange() {
        super(1.5f);
    }

    @Override
    public String toString(){
        return "апельсины";
    }

}
