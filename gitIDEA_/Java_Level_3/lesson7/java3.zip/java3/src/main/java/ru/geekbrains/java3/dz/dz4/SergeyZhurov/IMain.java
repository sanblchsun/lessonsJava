package ru.geekbrains.java3.dz.dz4.SergeyZhurov;

public interface IMain {

    //Task2 constants
    String FILE_NAME = "./src/main/java/ru/geekbrains/java3/dz/dz4/SergeyZhurov/Task2/Task2.txt";

    String[] OUTPUT1 = {"Thread_1_out_1", "Thread_1_out_2", "Thread_1_out_3", "Thread_1_out_4", "Thread_1_out_5",
                        "Thread_1_out_6", "Thread_1_out_7", "Thread_1_out_8", "Thread_1_out_9", "Thread_1_out_10"};
    String[] OUTPUT2 = {"Thread_2_out_1", "Thread_2_out_2", "Thread_2_out_3", "Thread_2_out_4", "Thread_2_out_5",
                        "Thread_2_out_6", "Thread_2_out_7", "Thread_2_out_8", "Thread_2_out_9", "Thread_2_out_10"};
    String[] OUTPUT3 = {"Thread_3_out_1", "Thread_3_out_2", "Thread_3_out_3", "Thread_3_out_4", "Thread_3_out_5",
                        "Thread_3_out_6", "Thread_3_out_7", "Thread_3_out_8", "Thread_3_out_9", "Thread_3_out_10"};

    String[] ITEMS = {"Item1", "Item2", "Item3", "Item4", "Item5"};

}
