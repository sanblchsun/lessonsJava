package ru.geekbrains.java3.dz.dz3.SergeyZhurov;

import java.io.File;

public interface Constants {
    File TASK1_FILE = new File("./src/main/java/ru/geekbrains/java3/dz/dz3/SergeyZhurov/res/Task1.txt");

    File TASK2_OUTPUT_FILE = new File("./src/main/java/ru/geekbrains/java3/dz/dz3/SergeyZhurov/res/Task2.txt");

    File TASK3_FILE = new File("./src/main/java/ru/geekbrains/java3/dz/dz3/SergeyZhurov/res/Task3.txt");
    int TASK3_PAGES = 8000;
    int TAKS3_PAGE_SIZE = 1800;
}
