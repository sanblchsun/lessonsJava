package ru.geekbrains.java3.dz.dz4.VeretennikovSergey;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class Task2 {
    private final Object mon = new Object();
    private String string;

    public Task2(String string) {
        this.string = string;
    }

    // метод записывает данные в файл
    public void printToFile() {
        for (int i = 0; i < 10; i++) {
            synchronized (mon) {
                try (BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter("dzTwo.txt", true))) {
                    bufferedWriter.write(string);
                    bufferedWriter.newLine();
                    System.out.println(string);
                } catch (IOException e) {
                    e.printStackTrace();
                }
                try {
                    Thread.sleep(50);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}
