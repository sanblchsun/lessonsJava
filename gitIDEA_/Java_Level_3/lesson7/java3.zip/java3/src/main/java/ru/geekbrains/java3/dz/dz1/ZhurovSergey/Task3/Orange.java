package ru.geekbrains.java3.dz.dz1.ZhurovSergey.Task3;

public class Orange extends Fruit {
}
