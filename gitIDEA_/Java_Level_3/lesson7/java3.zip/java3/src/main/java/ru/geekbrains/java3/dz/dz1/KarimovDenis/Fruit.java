package ru.geekbrains.java3.dz.dz1.KarimovDenis;

import java.util.ArrayList;

public class Fruit {

    public static void main(String[] args) {
        ArrayList<Integer> boxApple = new ArrayList<>(5);
        ArrayList<Integer> boxOrange = new ArrayList<>(7);



    }

}
