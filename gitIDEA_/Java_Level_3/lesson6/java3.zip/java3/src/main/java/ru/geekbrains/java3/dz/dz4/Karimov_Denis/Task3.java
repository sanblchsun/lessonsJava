package ru.geekbrains.java3.dz.dz4.Karimov_Denis;

public class Task3 {

}
