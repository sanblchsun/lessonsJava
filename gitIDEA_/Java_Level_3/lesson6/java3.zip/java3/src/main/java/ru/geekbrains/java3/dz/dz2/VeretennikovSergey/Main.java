package ru.geekbrains.java3.dz.dz2.VeretennikovSergey;

/*
  Created by on 03.02.2018.
  @author Sergey Veretennikov

  1. Сформировать таблицу товаров (id, prodid, title, cost) запросом из Java приложения.
  id - порядковый номер записи, первичный ключ
  prodid - уникальный номер товара
  title - название товара
  cost - стоимость

  2. При запуске приложения очистить таблицу и заполнить 10.000 товаров вида:
  id_товара 1 товар1 10
  id_товара 2 товар2 20
  id_товара 3 товар3 30
  ...
  id_товара 10000 товар10000 100010

  3. Написать консольное приложение, которое позволяет узнать цену товара по его имени, либо вывести
  сообщение "Такого товара нет" если товара нет в базе. Консольная команда: "/цена товар545".

  4. Добавить возможность изменения цены товара(указываем имя товара и новую цену). Консольная команда:
​  "/сменитьцену товар10 10000"

  5. Вывести товары в заданном ценовом диапазоне. Консольная команда: "/товарыпоцене 100 600"
 */


import java.sql.*;
import java.util.Scanner;

public class Main {
    private static final String DB_URL = "jdbc:postgresql://localhost:5432/postgres";
    private static final String LOGIN = "postgres";
    private static final String PASSWORD = "1";
    private static Connection connection;
    private static PreparedStatement preparedStatement;
    private static Statement statement;
    public static Scanner scaner = new Scanner(System.in);

    public static void main(String[] args) {
        try {
            DriverManager.registerDriver(new org.postgresql.Driver());
        } catch (SQLException e) {
            e.printStackTrace();
        }
        try {
            connection = DriverManager.getConnection(DB_URL, LOGIN, PASSWORD);

            if (connection != null) {
                System.out.println("Подключение к базе данных прошло успешно!\n");
                sqlCreateTable();
                sqlClear();
                sqlInsertRandomData();
                sqlSelectAll();

                System.out.println("Используйте команды: ");
                System.out.println("/цена {ТОВАР}                                Например: /цена Товар1");
                System.out.println("/сменитьцену {ТОВАР} {ЦЕНА}                  Например: /сменитьцену Товар1  10 ");
                System.out.println("/товарыпоцене {ЦЕНА ОТ} {ЦЕНА ДО}            Например: /товарыпоцене  10  100  ");
                System.out.println("/выход");

                while (true) {
                    System.out.println("Введите команду:");
                    String response = scaner.nextLine();
                    if (response.startsWith("/цена")) {
                        sqlSelectPrice(response.split(" ")[1]);
                    } else if (response.startsWith("/сменитьцену")) {
                        sqlUpdatePrice(response.split(" ")[1], Double.parseDouble(response.split(" ")[2]));
                    } else if (response.startsWith("/товарыпоцене")) {
                        sqlSelectPricesBetween(Double.parseDouble(response.split(" ")[1]), Double.parseDouble(response.split(" ")[2]));
                    } else if (response.startsWith("/выход")) {
                        break;
                    } else System.out.println("Команда некорректна!");
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Не смогли подключиться к базе данных");

        } finally {
            try {
                connection.close();
                System.out.println("Закрываем соединение...");
            } catch (SQLException e) {
                e.printStackTrace();
                System.out.println("Не удалось закрыть соединений!");
            }
        }
    }

    // метод поиска товаров по диапазону цен
    private static void sqlSelectPricesBetween(Double from, Double to) {
        try {
            preparedStatement = connection.prepareStatement("SELECT * FROM Goods WHERE cost BETWEEN ? AND ?");
            preparedStatement.setDouble(1, from);
            preparedStatement.setDouble(2, to);
            ResultSet resultSet = preparedStatement.executeQuery();
            printAllColunms(resultSet);
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Поиск не удался....");
        }
    }

    // метод замены цены товара на указанный
    private static void sqlUpdatePrice(String title, Double cost) {
        try {
            preparedStatement = connection.prepareStatement("UPDATE Goods SET cost = ? WHERE title = ?");
            preparedStatement.setDouble(1, cost);
            preparedStatement.setString(2, title);
            preparedStatement.executeUpdate();
            sqlSelectPrice(title);
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Замена не удалась....");
        }
    }

    //  метод поиска товара по названию
    private static void sqlSelectPrice(String title) {
        try {
            preparedStatement = connection.prepareStatement("SELECT title, cost FROM Goods WHERE title = ?");
            preparedStatement.setString(1, title);
            ResultSet resultSet = preparedStatement.executeQuery();
            if (resultSet.next()) {
                do {
                    String title1 = resultSet.getString("title");
                    Double cost = resultSet.getDouble("cost");
                    System.out.println("[" + title1 + "|" + cost + "]");
                } while (resultSet.next());
            } else System.out.println("Такого товара нет: " + title);
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Поиск не удался...");
        }
    }

    // метод очистки базы данных
    private static void sqlClear() {
        try {
            statement = connection.createStatement();
            statement.executeUpdate("DELETE FROM Goods");
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Не удалось очистить базу данных");
        }
    }

    // метод вывода всей базы данных
    private static void sqlSelectAll() {
        try {
            statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery("SELECT * FROM Goods");
            printAllColunms(resultSet);
        } catch (SQLException e) {
            e.printStackTrace();
        }

    }

    // метод вывода полученных данных
    private static void printAllColunms(ResultSet resultSet) throws SQLException {
        if (resultSet.next()) {
            do {
                String id = resultSet.getString("id");
                String prodid = resultSet.getString("prodid");
                String title = resultSet.getString("title");
                String cost = resultSet.getString("cost");
                System.out.println("[ " + id + " | " + prodid + " | " + title + " | " + cost + " ] ");
            } while (resultSet.next());
        } else System.out.println("В выборке 0 записей");

    }

    // метод заполнения данными базу данных
    private static void sqlInsertRandomData() {
        try {
            preparedStatement = connection.prepareStatement("INSERT INTO Goods (prodid, title, cost) VALUES (?, ?, ?)");
            for (int i = 1; i < 10001; i++) {
                preparedStatement.setInt(1, (i * 10));
                preparedStatement.setString(2, "Товар" + i);
                preparedStatement.setDouble(3, (0 + Math.random() * 10000000 / 100));
                preparedStatement.executeUpdate();
            }
            System.out.println("Таблица заполнена");
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Не удалось заполнить таблицу");
        }

    }

    // метод проверяет создана база данных, если нет, то создать
    private static void sqlCreateTable() {
        try {
            statement = connection.createStatement();
            statement.executeUpdate("CREATE TABLE IF " +
                    "NOT EXISTS Goods(" +
                    "id serial NOT NULL," +
                    "prodid numeric NOT NULL," +
                    "title text NOT NULL," +
                    "cost numeric(1000,2) NOT NULL," +
                    "CONSTRAINT id PRIMARY KEY (id)," +
                    "CONSTRAINT prodid UNIQUE (prodid))" +
                    "WITH (OIDS = FALSE);" +
                    "ALTER TABLE Goods OWNER TO postgres;");
            System.out.println("Таблица создана");
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Ошибка создания Таблицы");
        }
    }
}
