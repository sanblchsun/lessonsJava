package ru.geekbrains.java3.lesson2.dz;

/**
 * Яблочки
 */
public class Apple extends Fruit {

    Apple() {
        super(1.0f);
    }

    @Override
    public String toString(){
        return "яблоки";
    }
}
