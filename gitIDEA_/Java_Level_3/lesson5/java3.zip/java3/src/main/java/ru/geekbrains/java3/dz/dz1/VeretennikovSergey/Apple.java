package ru.geekbrains.java3.dz.dz1.VeretennikovSergey;

public class Apple extends Fruit {
    private float weight = 1.0f;

    @Override
    public float getWeight() {
        return weight;
    }
}
