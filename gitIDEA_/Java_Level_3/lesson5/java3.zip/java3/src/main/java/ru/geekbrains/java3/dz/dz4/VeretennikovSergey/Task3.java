package ru.geekbrains.java3.dz.dz4.VeretennikovSergey;

public class Task3 {
    private final Object mon = new Object();
    private volatile char currentState = 's';
    private int count;

    public Task3(int count) {
        this.count = count;
    }

    // метод печатания документов в консоль
    public void printDocuments() {
        synchronized (mon) {
            try {
                for (int i = 0; i < count; i++) {
                    while (currentState != 'p') mon.wait();
                    System.out.println("Распечатано: " + (i + 1) + " страниц");
                    currentState = 's';
                    Thread.sleep(50);
                    mon.notify();
                }
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

        }
    }

    // метод сканирования документов в консоль
    public void scanDocuments() {
        synchronized (mon) {
            try {
                for (int i = 0; i < count; i++) {
                    while (currentState != 's') mon.wait();
                    System.out.println("Отсканировано: " + (i + 1) + " страниц");
                    currentState = 'p';
                    Thread.sleep(50);
                    mon.notify();
                }
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    //Запускаем два потока, в одном идет печать документов, в другом идет сканирование документов
    public void run() {
        new Thread(() -> printDocuments()).start();
        new Thread(() -> scanDocuments()).start();
    }

}
