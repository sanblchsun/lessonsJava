package ru.geekbrains.java3.dz.dz4.VeretennikovSergey;

public class Task1 {
    private final Object mon = new Object();
    private volatile char currentLetter = 'A';

    // создаем и запускаем 3 потока
    public void run() {
        new Thread(() -> printA()).start();
        new Thread(() -> printB()).start();
        new Thread(() -> printC()).start();
    }

    // проверяем переменную currentLetter если равна А, то выводим А и запускаем потоки, если не равно А
    // останавливаем поток
    public void printA() {
        synchronized (mon) {
            try {
                for (int i = 0; i < 5; i++) {
                    while (currentLetter != 'A') mon.wait();
                    System.out.print("A");
                    currentLetter = 'B';
                    mon.notifyAll();
                }
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    // проверяем переменную currentLetter если равна В, то выводим В и запускаем потоки, если не равно В
    // останавливаем поток
    public void printB() {
        synchronized (mon) {
            try {
                for (int i = 0; i < 5; i++) {
                    while (currentLetter != 'B') mon.wait();
                    System.out.print("B");
                    currentLetter = 'C';
                    mon.notifyAll();
                }
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    // проверяем переменную currentLetter если равна С, то выводим С и запускаем потоки, если не равно С
    // останавливаем поток
    public void printC() {
        synchronized (mon) {
            try {
                for (int i = 0; i < 5; i++) {
                    while (currentLetter != 'C') mon.wait();
                    System.out.print("C");
                    currentLetter = 'A';
                    mon.notifyAll();
                }
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}
