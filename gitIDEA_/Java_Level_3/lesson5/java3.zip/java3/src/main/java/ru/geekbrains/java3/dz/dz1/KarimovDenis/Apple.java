package ru.geekbrains.java3.dz.dz1.KarimovDenis;

public class Apple extends Fruit {
    public Object apple = new Object();

}
