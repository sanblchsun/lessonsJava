package ru.geekbrains.java3.dz.dz1;

/**
 *
 * @author friar
 */
public class Orange extends Fruit{

    public Orange() {
        super.setWeight(0.2);
        super.setFruitName("Orange");
    }
    
    
}