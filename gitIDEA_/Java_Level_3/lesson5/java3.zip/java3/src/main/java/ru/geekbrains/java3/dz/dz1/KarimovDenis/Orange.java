package ru.geekbrains.java3.dz.dz1.KarimovDenis;

public class Orange extends Fruit{
    public Object orange = new Object();

}
