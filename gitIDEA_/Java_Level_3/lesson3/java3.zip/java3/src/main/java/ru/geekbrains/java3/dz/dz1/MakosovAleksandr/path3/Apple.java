package ru.geekbrains.java3.dz.dz1.MakosovAleksandr.path3;

public class Apple extends Fruit {
    public Apple(String name, Float weight) {
        super(name, weight);
    }
}
