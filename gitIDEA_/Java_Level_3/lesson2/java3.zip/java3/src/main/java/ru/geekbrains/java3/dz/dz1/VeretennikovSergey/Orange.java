package ru.geekbrains.java3.dz.dz1.VeretennikovSergey;

public class Orange extends Fruit {
    private float weight = 1.5f;

    @Override
    public float getWeight() {
        return weight;
    }
}
