package ru.geekbrains.java3.dz.dz1;

/**
 *
 * @author friar
 */
public class Banana extends Fruit {
    
    public Banana() {
        super.setWeight(0.3);
        super.setFruitName("Banana");
    }    
}
