package ru.geekbrains.java3.dz.dz1.ZhurovSergey.Task3;

public class Apple extends Fruit {
}
