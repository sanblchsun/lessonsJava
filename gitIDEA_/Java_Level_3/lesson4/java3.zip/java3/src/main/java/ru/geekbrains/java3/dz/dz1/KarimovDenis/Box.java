package ru.geekbrains.java3.dz.dz1.KarimovDenis;

import java.util.ArrayList;

public class Box <T>{

    private T ArrayList;

    public Box(T arrayList) {
        ArrayList = arrayList;
    }

    public T getArrayList() {
        return ArrayList;
    }

    public void setArrayList(T ArrayList) {
        this.ArrayList= ArrayList;
    }

    public void getWeight(){

    }
}
